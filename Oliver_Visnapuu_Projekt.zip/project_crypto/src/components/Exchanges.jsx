import React from 'react'

export const Exchanges = () => {
  return (
    <div>Exchanges</div>
  )
}

export default Exchanges